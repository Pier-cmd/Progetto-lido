package work.service;

import work.model.Prenotazione;

public interface PrenotazioneService {

	void createPrenotazione(Prenotazione p);
	void updatePrenotazione(Prenotazione p);
	void deletePrenotazione(Prenotazione p);
}
