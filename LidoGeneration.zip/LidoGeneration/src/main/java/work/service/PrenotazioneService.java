package work.service;

import work.model.Prenotazione;


public interface PrenotazioneService {

	void createPrenotazione(Prenotazione p);
	void updatePrenotazione(Prenotazione p);
	void deletePrenotazione(Prenotazione p);
	int getDurataPrenotazione(Prenotazione p);
	double sommaTotale(Prenotazione prenotazioneSelezionata,int numeroSedie, int numeroLettini, int numeroParcheggi);
	Prenotazione getPrenotazioneById(int id);
	int getLastPrenotazioneId();
	String REGEX = "[a-zA-Z'\\s]{1,255}";
	String REGEX2 = "[0-9]{1,15}";
	boolean checkData(String...data);
	boolean checkDate(int duratagg);
}