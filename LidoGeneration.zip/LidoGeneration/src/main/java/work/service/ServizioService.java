package work.service;

import work.model.Servizio;

public interface ServizioService {

	public Servizio getServizioById(int id);
}
