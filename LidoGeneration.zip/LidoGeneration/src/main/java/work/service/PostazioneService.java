package work.service;

import java.util.List;

import work.model.Postazione;

public interface PostazioneService {

	List<Postazione> getPostazione();
	Postazione getPostazioneById(int id);
	
	void updatePostazione(Postazione p);
}
