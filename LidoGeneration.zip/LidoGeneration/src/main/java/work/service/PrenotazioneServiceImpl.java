package work.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import work.dao.PrenotazioneDao;
import work.model.Prenotazione;

@Service
public class PrenotazioneServiceImpl  implements PrenotazioneService{

	@Autowired
	private PrenotazioneDao prenotazioneDao;

	@Override
	public void createPrenotazione(Prenotazione p) {
		prenotazioneDao.creatPrenotazione(p);
	}

	@Override
	public void updatePrenotazione(Prenotazione p) {
		prenotazioneDao.updatePrenotazione(p);
	}

	@Override
	public void deletePrenotazione(Prenotazione p) {
		prenotazioneDao.deletePrenotazione(p);
	}
	
	
}
