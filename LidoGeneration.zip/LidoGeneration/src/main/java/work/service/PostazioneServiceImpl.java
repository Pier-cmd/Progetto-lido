package work.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import work.dao.PostazioneDao;
import work.model.Postazione;

@Service
public class PostazioneServiceImpl implements PostazioneService{

	@Autowired
	private PostazioneDao postazioneDao;

	@Override
	public List<Postazione> getPostazione() {
		
		return postazioneDao.getPostazione();
	}

	@Override
	public Postazione getPostazioneById(int id) {
		return postazioneDao.getPostazioneById(id);
	}
	
	
}
