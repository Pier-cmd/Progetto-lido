package work.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import work.model.Postazione;
import work.model.Prenotazione;
import work.service.PostazioneService;
import work.service.PrenotazioneService;

@Controller
@RequestMapping(path= {"/", "/home", "/spiaggia"})
public class SpiaggiaController {
	
	@Autowired
	private PostazioneService postazioneService;
	
	@Autowired
	private PrenotazioneService prenotazioneService;
	

	@GetMapping
	public String getPage(Model model) {
		model.addAttribute("title", "Ombrelloni Liberi");
		postazioneService.getPostazione();
		 
		List<Postazione> postazioniFilaA = new ArrayList<>();
		List<Postazione> postazioniFilaB = new ArrayList<>();
		List<Postazione> postazioniFilaC = new ArrayList<>();
		
		
		for(int i = 0; i<postazioneService.getPostazione().size(); i++) {
			if(postazioneService.getPostazione().get(i).getFila().equals("A"))
				postazioniFilaA.add(postazioneService.getPostazione().get(i));
			if(postazioneService.getPostazione().get(i).getFila().equals("B"))
				postazioniFilaB.add(postazioneService.getPostazione().get(i));
			if(postazioneService.getPostazione().get(i).getFila().equals("C"))
				postazioniFilaC.add(postazioneService.getPostazione().get(i));
		}
		
		List<List<Postazione>> schemaPostazioni = new ArrayList<>();
		schemaPostazioni.add(postazioniFilaA);
		schemaPostazioni.add(postazioniFilaB);
		schemaPostazioni.add(postazioniFilaC);
		
		model.addAttribute("schemaPostazioni", schemaPostazioni);
		
		return "spiaggia";
	}
	
	@GetMapping("/deleteprenotazione")
	public String deletePrenotazione(@RequestParam("id") int id)
	{
		Prenotazione prenotazione = prenotazioneService.getPrenotazioneById(id);
		
		Postazione postazione = postazioneService.getPostazioneById(prenotazione.getPostazione().getId());
		postazione.setStato(0);
		postazioneService.updatePostazione(postazione);
		prenotazione.setPostazione(null);
	    prenotazioneService.updatePrenotazione(prenotazione);
		prenotazioneService.deletePrenotazione(prenotazione);
		
		
		
		return "redirect:/";
	}
	
}
