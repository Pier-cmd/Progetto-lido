package work.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import work.model.Postazione;
import work.service.PostazioneService;

@Controller
@RequestMapping(path= {"/", "/home", "/spiaggia"})
public class SpiaggiaController {
	
	@Autowired
	private PostazioneService postazioneService;
	
	private Postazione postazione;

	@GetMapping
	public String getPage(Model model) {
		model.addAttribute("title", "Ombrelloni Liberi");
		postazioneService.getPostazione();
		 
		List<Postazione> postazioniFilaA = new ArrayList<>();
		List<Postazione> postazioniFilaB = new ArrayList<>();
		List<Postazione> postazioniFilaC = new ArrayList<>();
		List<Postazione> postazioniFilaD = new ArrayList<>();
		
		for(int i = 0; i<postazioneService.getPostazione().size(); i++) {
			if(postazioneService.getPostazione().get(i).getFila().equals("A"))
				postazioniFilaA.add(postazioneService.getPostazione().get(i));
			if(postazioneService.getPostazione().get(i).getFila().equals("B"))
				postazioniFilaB.add(postazioneService.getPostazione().get(i));
			if(postazioneService.getPostazione().get(i).getFila().equals("C"))
				postazioniFilaC.add(postazioneService.getPostazione().get(i));
			if(postazioneService.getPostazione().get(i).getFila().equals("D"))
				postazioniFilaD.add(postazioneService.getPostazione().get(i));
		}
		
		List<List<Postazione>> schemaPostazioni = new ArrayList<>();
		schemaPostazioni.add(postazioniFilaA);
		schemaPostazioni.add(postazioniFilaB);
		schemaPostazioni.add(postazioniFilaC);
		schemaPostazioni.add(postazioniFilaD);
		
		model.addAttribute("schemaPostazioni", schemaPostazioni);
		
		return "spiaggia";
	}
	
}
