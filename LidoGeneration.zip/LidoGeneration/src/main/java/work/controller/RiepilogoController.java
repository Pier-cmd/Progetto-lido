package work.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import work.model.Postazione;
import work.model.Prenotazione;
import work.model.Servizio;
import work.service.PostazioneService;
import work.service.PrenotazioneService;


@Controller
@RequestMapping("/riepilogo")
public class RiepilogoController 
{

@Autowired
private PrenotazioneService prenotazioneService;
@Autowired
private PostazioneService postazioneService;

int idPrenotazione;

@GetMapping
public String getPage(@RequestParam("id") int id, Model model )
{
	idPrenotazione = id;
	Prenotazione p = prenotazioneService.getPrenotazioneById(id);
	List<Servizio> sedie = new ArrayList<>(); 
	List<Servizio> lettini = new ArrayList<>();
	List<Servizio> parcheggi = new ArrayList<>();
	for(Servizio s : p.getServizi())
		
	{
		if(s.getDescrizione().equals("Sedia"))
			sedie.add(s);
		if(s.getDescrizione().equals("Lettino"))
			lettini.add(s);
		if(s.getDescrizione().equals("Parcheggio"))
			parcheggi.add(s);
	}
	model.addAttribute("sedie", sedie);
	model.addAttribute("lettini", lettini);
	model.addAttribute("parcheggi", parcheggi);
	model.addAttribute("prenotazione", p);
	model.addAttribute("postazione", p.getPostazione());
	
return "riepilogo";
	
}

@PostMapping("/conferma")
@ResponseBody
public String getConferma(@RequestParam("pagato") boolean pagato, Model model)
{
    Prenotazione p = prenotazioneService.getPrenotazioneById(idPrenotazione);
    Postazione postazione = postazioneService.getPostazioneById(p.getPostazione().getId());
    if(pagato)
      postazione.setStato(2);
    else 
        postazione.setStato(1);
    postazioneService.updatePostazione(postazione);
    return "pagamentoOk";
}

}