package work.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import work.model.Postazione;
import work.model.Prenotazione;
import work.model.Servizio;
import work.service.PostazioneService;
import work.service.PrenotazioneService;

@Controller
@RequestMapping("/prenotazione")
public class PrenotazioneController {
	
	@Autowired
	private PostazioneService postazioneService;
	
	@Autowired
	private PrenotazioneService prenotazioneService;
	
	private Postazione postazione;
	
	@GetMapping
	public String getPage
	(Model model,
	@RequestParam("id") int id,
	@RequestParam(name="fe", required=false) String fError,
	Servizio servizio) {
		boolean formError = fError == null ? false: true;
		postazione=postazioneService.getPostazioneById(id);
		model.addAttribute("title", "Pagina prenotazioni");
		model.addAttribute("postazione", postazione);
		model.addAttribute("prenotazione", new Prenotazione());
		model.addAttribute("formError", formError);
		model.addAttribute("servizio", servizio);
	
		return "prenotazione";
	}
	
	@PostMapping("/registra")
	public String registra
	(@Valid @ModelAttribute("prenotazione") Prenotazione prenotazione,
	BindingResult result) {
		if(result.hasErrors())
			return "prenotazione";
		
		
		prenotazioneService.createPrenotazione(prenotazione);
		return "redirect:/riepilogo";
	}

}
