package work.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import work.model.Postazione;
import work.model.Prenotazione;
import work.model.Servizio;
import work.service.PostazioneService;
import work.service.PrenotazioneService;
import work.service.ServizioService;

@Controller
@RequestMapping("/prenotazione")
public class PrenotazioneController {
	
	@Autowired
	private ServizioService servizioService;
	
	@Autowired
	private PostazioneService postazioneService;
	
	@Autowired
	private PrenotazioneService prenotazioneService;
	
	private Postazione postazione;
	
	private Prenotazione prenotazioneSelezionata;
	private int idPostazione;
	
	@GetMapping
	public String getPage
	(Model model,
	@RequestParam(name="fe", required=false) String fError,
	@RequestParam(name="er", required=false)String dError,
	@RequestParam("id") int id,
	Servizio servizio) {
		idPostazione =id;
		prenotazioneSelezionata = new Prenotazione();
		boolean formError = fError == null ? false: true;
		boolean dateError = dError == null ? false: true;
		model.addAttribute("title", "Pagina prenotazioni");
		postazione=postazioneService.getPostazioneById(id);
		model.addAttribute("postazione", postazione);
		model.addAttribute("dateError", dateError);
		model.addAttribute("formError", formError);
		model.addAttribute("prenotazione", prenotazioneSelezionata);
		prenotazioneSelezionata.setPostazione(postazione);
		System.out.println(prenotazioneSelezionata.getPostazione().getId());
		
		return "prenotazione";
	}
	
	@PostMapping("/registra")
	public String registra
	(@RequestParam("cognome") String cognome,
	@RequestParam("dataInizio") String dataInizio,
	@RequestParam("dataFine") String dataFine,
	@RequestParam("tel") String tel,
	@RequestParam("numeroSedie") String numeroSedie,
	@RequestParam("numeroLettini") String numeroLettini,
	@RequestParam("numeroParcheggi") String numeroParcheggi,
	Model model) {
	
		
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date inizio = null;
		Date fine = null;
		try {
			inizio = format.parse(dataInizio);
			fine = format.parse(dataFine);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		
		
		postazione = postazioneService.getPostazioneById(idPostazione);
		prenotazioneSelezionata.setPostazione(postazione);
		prenotazioneSelezionata.setNominativoCliente(cognome);
		prenotazioneSelezionata.setDataInizio(inizio);
		prenotazioneSelezionata.setDataFine(fine);
		prenotazioneSelezionata.setTelefono(tel);
		prenotazioneSelezionata.setDurataGiorni(prenotazioneService.getDurataPrenotazione(prenotazioneSelezionata));
		prenotazioneSelezionata.setPrezzoGlobale(prenotazioneService.sommaTotale(prenotazioneSelezionata, Integer.parseInt(numeroSedie), Integer.parseInt(numeroLettini), Integer.parseInt(numeroParcheggi)));
		
	if(!prenotazioneService.checkData(cognome,tel))
		return "redirect:/prenotazione?id=" + postazione.getId() + "&fe";
	
	
		if(!prenotazioneService.checkDate(prenotazioneSelezionata.getDurataGiorni()))
			return "redirect:/prenotazione?id=" + postazione.getId() + "&er";
		System.out.println(prenotazioneSelezionata.getPostazione().getId());
		prenotazioneService.createPrenotazione(prenotazioneSelezionata);
		
		
		return "redirect:/riepilogo?id="+prenotazioneService.getLastPrenotazioneId();
	}

}