package work.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import work.model.Prenotazione;

@Repository
public class PrenotazioneDaoImpl implements PrenotazioneDao{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Autowired
	PostazioneDao postazione;

	
	@Override
	@Transactional
	public void createPrenotazione(Prenotazione p) {
		
		//int id = p.getPostazione().getId();
		
		manager.persist(p);
		p.getPostazione().setStato(1);
		postazione.updatePostazione(p.getPostazione());
	//	String sql = "UPDATE postazioni SET stato=1 WHERE id=" + id;
	//	manager.createNativeQuery(sql);
		
		
	}

	@Override
	@Transactional
	public void updatePrenotazione(Prenotazione p) {
		manager.merge(p);
	}

	@Override
	@Transactional
	public void deletePrenotazione(Prenotazione p) {
		manager.remove(manager.merge(p));
	}



	@Override
	public Prenotazione getPrenotazioneById(int id) {
		
		return manager.find(Prenotazione.class, id);
	}

	@Override
	public int getLastPrenotazioneId() {
		
		String sqlString = "SELECT MAX(id) FROM prenotazioni";
		
		return (int) manager.createNativeQuery(sqlString).getSingleResult();
	}
	
	

}
