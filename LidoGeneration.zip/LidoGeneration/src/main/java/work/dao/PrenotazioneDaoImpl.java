package work.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import work.model.Prenotazione;

@Repository
public class PrenotazioneDaoImpl implements PrenotazioneDao{
	
	@PersistenceContext
	private EntityManager manager;

	@Override
	@Transactional
	public void creatPrenotazione(Prenotazione p) {
		manager.persist(p);
		
	}

	@Override
	@Transactional
	public void updatePrenotazione(Prenotazione p) {
		manager.merge(p);
	}

	@Override
	@Transactional
	public void deletePrenotazione(Prenotazione p) {
		manager.remove(manager.merge(p));
	}
	
	

}
