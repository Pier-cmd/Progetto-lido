package work.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import work.model.Servizio;

@Repository
public class ServizioDaoImpl implements ServizioDao {

	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public Servizio getServizioById(int id) {
		
		return manager.find(Servizio.class, id);
	}

	
}