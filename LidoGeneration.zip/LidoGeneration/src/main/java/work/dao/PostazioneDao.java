package work.dao;

import java.util.List;

import work.model.Postazione;

public interface PostazioneDao {

	List<Postazione> getPostazione();
	Postazione getPostazioneById(int id);
	void updatePostazione(Postazione p);
}
