package work.dao;

import work.model.Prenotazione;

public interface PrenotazioneDao {

	void createPrenotazione(Prenotazione p);
	void updatePrenotazione(Prenotazione p);
	void deletePrenotazione(Prenotazione p);
	Prenotazione getPrenotazioneById(int id);
	int getLastPrenotazioneId();
}