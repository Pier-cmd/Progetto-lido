package work.dao;

import work.model.Prenotazione;

public interface PrenotazioneDao {

	void creatPrenotazione(Prenotazione p);
	void updatePrenotazione(Prenotazione p);
	void deletePrenotazione(Prenotazione p);
}
