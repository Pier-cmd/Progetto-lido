package work.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="postazioni")
public class Postazione implements Serializable{

	private static final long serialVersionUID = 4862657658783857308L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="fila", length = 2, nullable = false)
	private String fila;
	
	@Column(name= "prezzo_al_giorno", nullable = false)
	private double prezzoAlGiorno;
	
	@Column(name="stato", nullable = false)
	private int stato;
	
	@OneToOne(mappedBy = "postazione", cascade = CascadeType.REFRESH)
	private Prenotazione prenotazione;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Prenotazione getPrenotazione() {
		return prenotazione;
	}

	public void setPrenotazione(Prenotazione prenotazione) {
		this.prenotazione = prenotazione;
	}

	public String getFila() {
		return fila;
	}

	public void setFila(String fila) {
		this.fila = fila;
	}

	public double getPrezzoAlGiorno() {
		return prezzoAlGiorno;
	}

	public void setPrezzoAlGiorno(double prezzoAlGiorno) {
		this.prezzoAlGiorno = prezzoAlGiorno;
	}

	public int getStato() {
		return stato;
	}

	public void setStato(int stato) {
		this.stato = stato;
	}
	
	

}