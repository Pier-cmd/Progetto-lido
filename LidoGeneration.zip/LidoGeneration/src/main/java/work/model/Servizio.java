package work.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="servizi")
public class Servizio implements Serializable{

	private static final long serialVersionUID = 327598126854570335L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Pattern(regexp= "[a-zA-Z\\s']{1,255}", message = "{error.charnotallowed}")
	@Column(name="descrizione", length = 255, nullable = false)
	private String descrizione;
	
	@Digits(integer = 4, fraction = 2, message = "{error.invalidamount}")
	@Column(name="prezzo_al_giorno", nullable = false)
	private double prezzoAlGiorno;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name="prenotazioni_servizi", joinColumns = @JoinColumn(name="id_prenotazioni", referencedColumnName = "id"),
	inverseJoinColumns = @JoinColumn(name="id_servizio", referencedColumnName = "id"))
	private List<Prenotazione> prenotazioni = new ArrayList<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public double getPrezzoAlGiorno() {
		return prezzoAlGiorno;
	}

	public void setPrezzoAlGiorno(double prezzoAlGiorno) {
		this.prezzoAlGiorno = prezzoAlGiorno;
	}

	public List<Prenotazione> getPrenotazioni() {
		return prenotazioni;
	}

	public void setPrenotazioni(List<Prenotazione> prenotazioni) {
		this.prenotazioni = prenotazioni;
	}

	
}
