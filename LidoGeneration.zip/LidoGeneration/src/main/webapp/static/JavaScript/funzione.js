$(document).ready(function()
{
    let pagato;
    
    $('#checkBox1').change(function()
    {
        if (this.checked)
            pagato = true;
        else
            pagato = false;
        sendData(pagato);
    });
  
  const sendData = (pagato) =>
    {
        $.post
        (
          'riepilogo/conferma',
          {
            pagato:pagato
          },
          function (response)
          {
            if (response === 'pagamentoOk')
            {
                if(pagato){
					$('#pagato').css({'display':'block'});
                    $('#annullato').css({'display':'none'});
                    }else{
	 				$('#annullato').css({'display':'block'});
                    $('#pagato').css({'display':'none'});
					}
                   
            }
                
          }
        );
    }
});
