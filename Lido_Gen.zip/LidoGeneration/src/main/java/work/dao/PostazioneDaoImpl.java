package work.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import work.model.Postazione;

@Repository
public class PostazioneDaoImpl implements PostazioneDao{

	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public List<Postazione> getPostazione() {
		String jpql = "SELECT p FROM Postazione p";
		return manager.createQuery(jpql).getResultList();
	}


	@Override
	public Postazione getPostazioneById(int id) {
		return manager.find(Postazione.class, id);
	}

}
