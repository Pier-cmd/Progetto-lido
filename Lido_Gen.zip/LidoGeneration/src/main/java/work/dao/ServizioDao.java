package work.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import work.model.Servizio;

public interface ServizioDao {

	Servizio getServizioById(int id);
}
