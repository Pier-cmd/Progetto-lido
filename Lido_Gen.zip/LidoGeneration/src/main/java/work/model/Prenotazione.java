package work.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name="prenotazioni")
public class Prenotazione implements Serializable{

	private static final long serialVersionUID = 1657555127991590504L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Pattern(regexp = "[a-zA-Z0-9\\s.']{1,255}", message = "{error.charnotallowed}")
	@Column(name = "nominativo_cliente", length = 100, nullable = false)
	private String nominativoCliente;
	
	@Column(name="data_inizio", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date dataInizio;
	
	@Column(name="data_fine", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date dataFine;
	
	@Digits(integer= 4, message = "{error.invalidamount}", fraction = 0)
	@Column(name="durata_giorni", nullable = false)
	private int durataGiorni;
	
	@Pattern(regexp = "[0-9\\s.+]{1,255}", message = "{error.charnotallowed}")
	@Column(name="telefono", length = 100, nullable = false)
	private String telefono;
	
	@Digits(integer= 4, fraction = 2, message = "{error.invalidamount}")
	@Column(name="prezzo_globale", nullable = false)
	private double prezzoGlobale;
	
	@OneToOne(cascade = CascadeType.REFRESH)
	@JoinColumn(name="id_postazione", referencedColumnName = "id")
	private Postazione postazione;
	
	@ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinTable(name="prenotazioni_servizi", joinColumns = @JoinColumn(name="id_prenotazione", referencedColumnName = "id"),
	inverseJoinColumns = @JoinColumn(name="id_servizio", referencedColumnName = "id"))
	@Fetch(FetchMode.SUBSELECT)
	private List<Servizio> servizi = new ArrayList<>();

	public Prenotazione(String nominativoCliente, Date dataInizio, Date dataFine, String telefono) {
		setNominativoCliente(nominativoCliente);
		setDataInizio(dataInizio);
		setDataFine(dataFine);
		setTelefono(telefono);
	}
	
	public Prenotazione () {
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNominativoCliente() {
		return nominativoCliente;
	}

	public void setNominativoCliente(String nominativoCliente) {
		this.nominativoCliente = nominativoCliente;
	}

	
	public Date getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(Date dataInizio) {
		this.dataInizio = dataInizio;
	}

	public Date getDataFine() {
		return dataFine;
	}

	public void setDataFine(Date dataFine) {
		this.dataFine = dataFine;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public int getDurataGiorni() {
		return durataGiorni;
	}

	public void setDurataGiorni(int durataGiorni) {
		this.durataGiorni = durataGiorni;
	}

	public double getPrezzoGlobale() {
		return prezzoGlobale;
	}

	public void setPrezzoGlobale(double prezzoGlobale) {
		this.prezzoGlobale = prezzoGlobale;
	}

	public Postazione getPostazione() {
		return postazione;
	}

	public void setPostazione(Postazione postazione) {
		this.postazione = postazione;
	}

	public List<Servizio> getServizi() {
		return servizi;
	}

	public void setServizi(List<Servizio> servizi) {
		this.servizi = servizi;
	}
	
	
	
}
