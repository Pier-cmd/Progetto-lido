package work.service;

import work.model.Prenotazione;
import work.model.Servizio;

public interface PrenotazioneService {

	void createPrenotazione(Prenotazione p);
	void updatePrenotazione(Prenotazione p);
	void deletePrenotazione(Prenotazione p);
	int getDurataPrenotazione(Prenotazione p);
	double sommaTotale(Prenotazione prenotazioneSelezionata,int numeroSedie, int numeroLettini, int numeroParcheggi);
	Prenotazione getPrenotazioneById(int id);
}
