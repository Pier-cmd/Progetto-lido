package work.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import work.dao.ServizioDao;
import work.model.Servizio;

@Service
public class ServizioServiceImpl implements ServizioService{

	@Autowired
	private ServizioDao servizioDao;
	
	@Override
	public Servizio getServizioById(int id) {
		return servizioDao.getServizioById(id);
	}

}
