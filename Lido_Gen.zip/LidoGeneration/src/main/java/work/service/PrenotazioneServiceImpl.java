package work.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import work.dao.PrenotazioneDao;
import work.model.Prenotazione;
import work.model.Servizio;

@Service
public class PrenotazioneServiceImpl  implements PrenotazioneService{

	@Autowired
	private PrenotazioneDao prenotazioneDao;
	
	@Autowired
	private ServizioService servizioService;
	
	private Servizio servizio;
	
	private Prenotazione prenotazione;

	@Override
	public void createPrenotazione(Prenotazione p) {
		prenotazioneDao.createPrenotazione(p);
		System.out.println("prenotazione per " + p.getNominativoCliente() + " registrato");
	}

	@Override
	public void updatePrenotazione(Prenotazione p) {
		prenotazioneDao.updatePrenotazione(p);
	}

	@Override
	public void deletePrenotazione(Prenotazione p) {
		prenotazioneDao.deletePrenotazione(p);
	}

	@Override
	public int getDurataPrenotazione(Prenotazione p) {
		long inizioTime = p.getDataInizio().getTime();
		long fineTime = p.getDataFine().getTime();
		
		long differenza = fineTime - inizioTime;
		int differenzaGiorni = (int)(differenza/86400000);
		
		return differenzaGiorni;
}

	@Override
	public double sommaTotale(Prenotazione prenotazioneSelezionata,int numeroSedie, int numeroLettini, int numeroParcheggi) {
		double sommaSedie = 0;
		double sommaLettini = 0;
		double sommaParcheggi = 0;
		
		for(int i =0; i<numeroSedie; i++) {
			Servizio servizioSedie = servizioService.getServizioById(1);
			prenotazioneSelezionata.getServizi().add(servizioSedie);
			sommaSedie += servizioSedie.getPrezzoAlGiorno();
		}
		
		for(int i =0; i<numeroLettini; i++) {
			Servizio servizioLettini = servizioService.getServizioById(2);
			prenotazioneSelezionata.getServizi().add(servizioLettini);
			sommaLettini += servizioLettini.getPrezzoAlGiorno();
		}
		
		for(int i =0; i<numeroParcheggi; i++) {
			Servizio servizioParcheggi = servizioService.getServizioById(3);
			prenotazioneSelezionata.getServizi().add(servizioParcheggi);
			sommaParcheggi += servizioParcheggi.getPrezzoAlGiorno();
		}
		
		double sommaServizi = sommaSedie + sommaParcheggi + sommaLettini +
				prenotazioneSelezionata.getPostazione().getPrezzoAlGiorno();
		
		double sommaGlobale = sommaServizi*prenotazioneSelezionata.getDurataGiorni();
		
		
		return sommaGlobale;
	}

	@Override
	public Prenotazione getPrenotazioneById(int id) {
		
		return prenotazioneDao.getPrenotazioneById(id);
	}
	
	
}
