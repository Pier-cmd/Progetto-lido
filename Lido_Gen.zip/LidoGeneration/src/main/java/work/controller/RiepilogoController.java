package work.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import work.model.Prenotazione;
import work.service.PrenotazioneService;

@Controller
@RequestMapping("/riepilogo")
public class RiepilogoController {
	
	@Autowired
	PrenotazioneService prenotazioneService;
	
	@GetMapping
	public String getPage(@RequestParam("id") int id) {
		Prenotazione prenotazione = prenotazioneService.getPrenotazioneById(id);
		return "riepilogo";
	}

}
